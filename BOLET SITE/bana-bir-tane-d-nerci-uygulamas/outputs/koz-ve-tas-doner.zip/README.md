# Köz & Taş Döner Atölyesi

Premium görünümlü, Türkçe ve mobil öncelikli konsept dönerci uygulaması. Ana ekranı, menüsü ve sepeti telefon ekranlarına göre tasarlanmıştır. PWA olarak ana ekrana kurulabilir; Capacitor yapılandırmasıyla Android ve iOS proje kabukları üretilebilir.

## Neler var?

- Ürün kategorileri, fiyat kartları ve cihazda saklanan favoriler
- Çalışan sepet, ürün adedi ve gel-al / adrese teslim örnek akışı
- Gün ve yerel saate göre açılış durumu ile haftalık çalışma saatleri
- Şube adresi, harita bağlantısı, hikâye ve alerjen uyarısı
- PWA manifesti, kurulum yönergesi, çevrimdışı uygulama kabuğu
- Native uygulama içinde hafif dokunsal geri bildirim için Capacitor Haptics
- Uygulama içinden açılabilen gizlilik açıklaması ve kullanım koşulları
- Play Store için 512×512, App Store için 1024×1024 ikon kaynağı ve iOS ana ekran ikonu

## Yerelde açma

Node.js 22+ kurulu bir bilgisayarda:

```sh
npm install
npm run start
```

Terminalin verdiği yerel adresi telefondan veya bilgisayardan açın. Dağıtım web dosyalarını üretmek için:

```sh
npm run build
```

## Android / iOS proje kabukları

Önce `npm run build` çalıştırın. Ardından hedef platform için bir kez:

```sh
npx cap add android
npx cap add ios
```

Web kodu değiştikçe yerel projelere aktarın:

```sh
npx cap sync
```

Android projesi Android Studio'da; iOS projesi macOS üzerinde Xcode'da açılır. Capacitor 8 geliştirme ortamı, hedef SDK'lar, sertifikalar, imzalama, mağaza hesapları ve mağaza başvuruları bu teslimata dahil değildir. Güncel resmi [Capacitor kurulum belgesi](https://capacitorjs.com/docs/getting-started/environment-setup) Node.js, Android Studio/Android SDK ve iOS için macOS/Xcode gereksinimlerini açıklar.

## Mağazaya göndermeden önce

Bu teslimat mağazaya yüklenmiş veya üretim siparişlerine bağlanmış bir uygulama değildir. Mağaza başvurusu için önce:

1. Örnek marka, adres, çalışma saatleri, iletişim, ürünler, fiyatlar ve harita konumunu gerçek şube bilgileriyle değiştirin.
2. Sepet ve örnek checkout akışını sipariş sunucusu, teslimat işleyişi, ödeme yöntemi ve müşteri destek akışıyla tamamlayın. Mevcut sürüm hiçbir siparişi restorana göndermez ve ödeme almaz.
3. Gerçek tarifleri ve alerjen/çapraz bulaşma bilgilerini doğrulayın. Mevcut içerik yalnızca örnektir.
4. Gizlilik metnini, gizlilik URL'sini, kullanım koşullarını ve mağaza veri beyanlarını gerçek ürünün kullandığı servislerle eşleştirin. Google Play, mağaza inceleme bilgileri ve veri güvenliği beyanı ister; ayrıntılar için [Google Play inceleme hazırlığı](https://support.google.com/googleplay/android-developer/answer/9859455) ve [Data safety açıklaması](https://support.google.com/googleplay/android-developer/answer/10787469) sayfalarına bakın.
5. Apple incelemesinden önce uygulamanın gerçek, yararlı bir sipariş deneyimi sunduğunu ve basit bir web sitesi sarmalından ibaret olmadığını cihazda doğrulayın. Apple'ın [4.2 Minimum Functionality](https://developer.apple.com/app-store/review/guidelines/) kuralı bu ayrımı açıkça belirtir.
6. Gerçek mağaza ekran görüntülerini, açıklamayı, yaş derecelendirmesini, destek/gizlilik URL'lerini ve iOS/Android imzalama ayarlarını hazırlayın.

Store onayı garanti edilemez; inceleme, tamamlanmış uygulamayı ve mağaza bilgilerini ayrı ayrı değerlendirir.

## Düzenlenecek başlangıç bilgileri

Ürünler ve fiyatlar `app.js` içinde; çalışma saatleri aynı dosyadaki `hours` dizisinde; şube/hikâye metinleri `index.html` içinde; uygulama adı ve paket kimliği `manifest.webmanifest` ile `capacitor.config.json` içinde bulunur.

Paket kimliği başlangıç değeri `com.kozvetas.doner`'dır; geliştirici hesabınızın benzersiz kimliğine göre mağazaya göndermeden önce değiştirin.

## Görsel kaynağı

Ana sayfada kullanılan iki örnek yemek görseli Unsplash sunucusundan yüklenir: [Vitaly Mazur — Türk kebap sunumu](https://unsplash.com/photos/a-white-plate-topped-with-meat-and-vegetables-1JSLIlFFvCY) ve [ThePowerCouple — tantuni dürüm](https://unsplash.com/photos/food-on-plate-0bEl03R6jVY). Bu görseller Unsplash lisansı altında ücretsiz kullanım için sunulmuştur. İlk çevrimiçi açılışta görsellerin yüklenmesi için internet gerekir; menü/uygulama kabuğu yerel önbellekte kullanılabilir.
