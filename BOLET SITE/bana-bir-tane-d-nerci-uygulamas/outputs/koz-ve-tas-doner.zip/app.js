(() => {
  "use strict";

  const products = [
    { id: "usta-durum", name: "Usta Dürüm", category: "dürüm", badge: "USTANIN SEÇİMİ", description: "İnce lavaş, közde dana döner, sumaklı soğan.", price: 15.9, art: "wrap", rating: "★ 4,9", vegetarian: false },
    { id: "dana-tabak", name: "Dana Döner Tabağı", category: "tabak", badge: "KLASİK", description: "Günlük kesim dana, tereyağlı pilav ve köz biber.", price: 19.4, art: "plate", rating: "★ 4,8", vegetarian: false },
    { id: "iskender", name: "Köz İskender", category: "tabak", badge: "USTA İŞİ", description: "Pide üstü döner, ev yapımı sos ve yoğurt.", price: 18.9, art: "iskender", rating: "★ 4,9", vegetarian: false },
    { id: "falafel", name: "Bahçe Dürüm", category: "dürüm", badge: "VEJETARYEN", description: "Falafel, taze otlar, turşu ve tahinli sos.", price: 13.9, art: "vegetarian", rating: "✳ Taze", vegetarian: true },
    { id: "ayran", name: "Taş Ayranı", category: "yanına", badge: "GÜNLÜK", description: "Serin, bol köpüklü, geleneksel usul.", price: 3.2, art: "side", rating: "✳ Ev yapımı", vegetarian: true },
    { id: "baklava", name: "Fıstıklı Baklava", category: "yanına", badge: "TATLI SON", description: "İnce katlar, Antep fıstığı, hafif şerbet.", price: 6.5, art: "sweet", rating: "✳ El açması", vegetarian: true }
  ];
  const categories = [
    { id: "all", label: "Tümü" }, { id: "dürüm", label: "Dürüm" },
    { id: "tabak", label: "Tabak & İskender" }, { id: "yanına", label: "Yanına güzel gider" },
    { id: "favorites", label: "Favorilerim" }
  ];
  const weekdays = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
  const hours = [
    { open: "12:00", close: "21:00" }, { open: "11:30", close: "22:00" },
    { open: "11:30", close: "22:00" }, { open: "11:30", close: "22:00" },
    { open: "11:30", close: "22:00" }, { open: "11:30", close: "23:00" },
    { open: "12:00", close: "23:00" }
  ];
  const currency = new Intl.NumberFormat("tr-TR", { style: "currency", currency: "EUR" });
  const storage = {
    read(key, fallback) {
      try { const value = JSON.parse(localStorage.getItem(key)); return value === null ? fallback : value; }
      catch { return fallback; }
    },
    write(key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); }
      catch { announce("Bu cihazda yerel kayıt kullanılamıyor."); }
    }
  };
  let cart = storage.read("koz-cart-v1", {});
  let favorites = storage.read("koz-favorites-v1", []);
  let activeCategory = "all";
  let fulfillment = "pickup";
  let deferredInstall = null;
  let toastTimer = 0;

  const productGrid = document.getElementById("productGrid");
  const categoryList = document.getElementById("categoryList");
  const cartCount = document.getElementById("cartCount");
  const cartDialog = document.getElementById("cartDialog");
  const checkoutDialog = document.getElementById("checkoutDialog");
  const cartContent = document.getElementById("cartContent");
  const toast = document.getElementById("toast");

  function money(value) { return currency.format(value); }
  function productFor(id) { return products.find((product) => product.id === id); }
  function cartEntries() {
    return Object.entries(cart)
      .map(([id, quantity]) => ({ product: productFor(id), quantity: Number(quantity) }))
      .filter((entry) => entry.product && Number.isFinite(entry.quantity) && entry.quantity > 0);
  }
  function subtotal() { return cartEntries().reduce((total, entry) => total + entry.product.price * entry.quantity, 0); }
  function deliveryFee() { return fulfillment === "delivery" ? 3.5 : 0; }
  function renderCategories() {
    categoryList.innerHTML = categories.map((category) =>
      '<button class="category-button' + (activeCategory === category.id ? " selected" : "") + '" type="button" aria-pressed="' + (activeCategory === category.id) + '" data-category="' + category.id + '">' + category.label + '</button>'
    ).join("");
  }
  function renderProducts() {
    const visible = products.filter((product) => {
      if (activeCategory === "favorites") return favorites.includes(product.id);
      if (activeCategory === "all") return true;
      return product.category === activeCategory;
    });
    if (!visible.length) {
      productGrid.innerHTML = '<div class="no-products">Henüz favoriniz yok. Beğendiğiniz üründeki kalbe dokunun.</div>';
      return;
    }
    productGrid.innerHTML = visible.map((product) =>
      '<article class="product-card">' +
        '<div class="product-art" data-art="' + product.art + '"><span class="product-art-label">' + product.badge + '</span>' +
          '<button class="product-favorite" type="button" data-action="favorite" data-id="' + product.id + '" aria-label="' + (favorites.includes(product.id) ? "Favorilerden çıkar: " : "Favorilere ekle: ") + product.name + '" aria-pressed="' + favorites.includes(product.id) + '"><svg><use href="#i-heart"/></svg></button>' +
        '</div><div class="product-card-body"><div class="product-meta"><span>' + (product.vegetarian ? "SEBZELİ & HAFİF" : "GÜNLÜK KESİM") + '</span><span class="product-rating">' + product.rating + '</span></div>' +
        '<h3>' + product.name + '</h3><p>' + product.description + '</p><div class="product-buy"><span class="product-price">' + money(product.price) + '</span><button class="add-button" type="button" data-action="add" data-id="' + product.id + '" aria-label="' + product.name + ' sepete ekle"><svg><use href="#i-plus"/></svg> Ekle</button></div></div></article>'
    ).join("");
  }
  function renderCartCount() {
    const count = cartEntries().reduce((sum, entry) => sum + entry.quantity, 0);
    cartCount.textContent = String(count);
    cartCount.setAttribute("aria-label", count + " ürün sepette");
  }
  function renderCart() {
    const entries = cartEntries();
    if (!entries.length) {
      cartContent.innerHTML = '<div class="cart-empty"><span><svg><use href="#i-bag"/></svg></span><h3>Sepetiniz henüz boş.</h3><p>Ateşten yeni çıkan bir şeyler seçelim mi?</p><a class="button button-dark" href="#menu" data-action="shop">Menüyü keşfet <svg><use href="#i-arrow"/></svg></a></div>';
      return;
    }
    const itemRows = entries.map(({ product, quantity }) =>
      '<div class="cart-row"><div class="cart-row-info"><strong>' + product.name + '</strong><small>' + money(product.price) + ' / adet</small></div><span class="cart-row-price">' + money(product.price * quantity) + '</span><div class="quantity-control"><button type="button" data-action="decrease" data-id="' + product.id + '" aria-label="' + product.name + ' adedini azalt"><svg><use href="#i-minus"/></svg></button><span>' + quantity + '</span><button type="button" data-action="increase" data-id="' + product.id + '" aria-label="' + product.name + ' adedini artır"><svg><use href="#i-plus"/></svg></button></div></div>'
    ).join("");
    cartContent.innerHTML = itemRows +
      '<div class="cart-summary"><div class="cart-summary-row"><span>Ara toplam</span><span>' + money(subtotal()) + '</span></div><div class="cart-summary-row"><span>Teslimat</span><span>Yönteme göre</span></div><div class="cart-summary-row total"><span>Toplam</span><span>' + money(subtotal()) + '</span></div><button class="button button-dark cart-cta" type="button" data-action="checkout">Sipariş bilgilerini gir <svg><use href="#i-arrow"/></svg></button><p class="cart-note">Fiyat ve teslimat bilgileri örnektir.</p></div>';
  }
  function renderHours() {
    const today = new Date();
    const todayIndex = today.getDay();
    const minutesNow = today.getHours() * 60 + today.getMinutes();
    const todayHours = hours[todayIndex];
    const toMinutes = (time) => Number(time.slice(0, 2)) * 60 + Number(time.slice(3));
    const isOpen = minutesNow >= toMinutes(todayHours.open) && minutesNow < toMinutes(todayHours.close);
    const status = document.getElementById("openStatus");
    status.classList.toggle("closed", !isOpen);
    status.querySelector("span").textContent = isOpen ? "Şu an açık" : "Şu an kapalı";
    document.getElementById("hoursList").innerHTML = weekdays.map((day, index) =>
      '<li class="' + (index === todayIndex ? "today" : "") + '"><span>' + day + (index === todayIndex ? " · Bugün" : "") + '</span><span>' + hours[index].open + ' – ' + hours[index].close + '</span></li>'
    ).join("");
  }
  function announce(message) {
    toast.textContent = message;
    toast.classList.add("show");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("show"), 2300);
  }
  function touchFeedback() {
    import("@capacitor/haptics").then(({ Haptics, ImpactStyle }) => Haptics.impact({ style: ImpactStyle.Light })).catch(() => {});
  }
  function persistCart() {
    cart = Object.fromEntries(Object.entries(cart).filter(([, quantity]) => quantity > 0));
    storage.write("koz-cart-v1", cart);
    renderCartCount();
    if (cartDialog.open) renderCart();
  }
  function openCheckout() {
    cartDialog.close();
    const form = document.getElementById("checkoutForm");
    form.hidden = false;
    document.getElementById("orderConfirmation").hidden = true;
    document.getElementById("customerAddress").required = fulfillment === "delivery";
    document.getElementById("addressField").hidden = fulfillment !== "delivery";
    document.getElementById("checkoutTotal").innerHTML = '<span>Örnek toplam</span><span>' + money(subtotal() + deliveryFee()) + '</span>';
    if (!checkoutDialog.open) checkoutDialog.showModal();
  }
  function updateFulfillment(mode) {
    fulfillment = mode;
    document.querySelectorAll(".fulfillment-option").forEach((button) => {
      const selected = button.dataset.mode === mode;
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
    document.getElementById("addressField").hidden = mode !== "delivery";
    document.getElementById("customerAddress").required = mode === "delivery";
    document.getElementById("checkoutTotal").innerHTML = '<span>Örnek toplam</span><span>' + money(subtotal() + deliveryFee()) + '</span>';
  }
  function toggleFavorite(id) {
    if (favorites.includes(id)) favorites = favorites.filter((favorite) => favorite !== id);
    else favorites = [...favorites, id];
    storage.write("koz-favorites-v1", favorites);
    renderProducts();
    touchFeedback();
    announce(favorites.includes(id) ? "Favorilerinize eklendi." : "Favorilerinizden çıkarıldı.");
  }
  function showFavorites() {
    activeCategory = "favorites";
    renderCategories();
    renderProducts();
    document.getElementById("menu").scrollIntoView({ behavior: "smooth" });
  }
  function showInstallHelp() {
    if (deferredInstall) {
      deferredInstall.prompt();
      deferredInstall.userChoice.finally(() => { deferredInstall = null; });
      return;
    }
    const agent = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(agent)) announce("Safari'de Paylaş'a dokunup ‘Ana Ekrana Ekle’yi seçin.");
    else announce("Tarayıcı menüsünü açıp ‘Uygulamayı yükle’ veya ‘Ana ekrana ekle’yi seçin.");
  }

  document.addEventListener("click", (event) => {
    const category = event.target.closest("[data-category]");
    if (category) {
      activeCategory = category.dataset.category;
      renderCategories();
      renderProducts();
      return;
    }
    const mode = event.target.closest("[data-mode]");
    if (mode) { updateFulfillment(mode.dataset.mode); return; }
    const actionButton = event.target.closest("[data-action]");
    if (!actionButton) return;
    const action = actionButton.dataset.action;
    const id = actionButton.dataset.id;
    if (action === "add") {
      cart[id] = (Number(cart[id]) || 0) + 1;
      persistCart();
      touchFeedback();
      announce(productFor(id).name + " sepetinize eklendi.");
    } else if (action === "increase") {
      cart[id] = (Number(cart[id]) || 0) + 1;
      persistCart();
      touchFeedback();
    } else if (action === "decrease") {
      cart[id] = (Number(cart[id]) || 0) - 1;
      persistCart();
      touchFeedback();
    } else if (action === "favorite") {
      toggleFavorite(id);
    } else if (action === "favorites") {
      showFavorites();
    } else if (action === "show-all") {
      activeCategory = "all";
      renderCategories();
      renderProducts();
      document.getElementById("menu").scrollIntoView({ behavior: "smooth" });
    } else if (action === "open-cart") {
      renderCart();
      cartDialog.showModal();
    } else if (action === "close-dialog") {
      actionButton.closest("dialog").close();
    } else if (action === "checkout") {
      openCheckout();
    } else if (action === "shop") {
      cartDialog.close();
    } else if (action === "finish-demo") {
      checkoutDialog.close();
      announce("Örnek akış tamamlandı; sepetiniz korundu.");
    } else if (action === "install") {
      showInstallHelp();
    }
  });

  [cartDialog, checkoutDialog].forEach((dialog) => dialog.addEventListener("click", (event) => {
    if (event.target === dialog) dialog.close();
  }));
  document.getElementById("checkoutForm").addEventListener("submit", (event) => {
    event.preventDefault();
    if (!event.currentTarget.reportValidity()) return;
    const formData = new FormData(event.currentTarget);
    const name = String(formData.get("name") || "").trim().split(/\s+/)[0];
    const itemCount = cartEntries().reduce((sum, entry) => sum + entry.quantity, 0);
    const methodText = fulfillment === "delivery" ? "adrese teslim" : "şubeden gel-al";
    document.getElementById("confirmationText").textContent = name + ", " + itemCount + " ürünlük " + methodText + " sipariş özeti hazırlandı.";
    event.currentTarget.hidden = true;
    document.getElementById("orderConfirmation").hidden = false;
  });
  document.querySelectorAll('a[href="#menu"]').forEach((link) => link.addEventListener("click", () => {
    if (link.matches("[data-action='shop']")) return;
    activeCategory = "all";
    renderCategories();
    renderProducts();
  }));
  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredInstall = event;
  });
  window.addEventListener("appinstalled", () => announce("Köz & Taş ana ekranınıza eklendi."));

  document.getElementById("year").textContent = String(new Date().getFullYear());
  renderCategories();
  renderProducts();
  renderCartCount();
  renderHours();
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
  }
})();
